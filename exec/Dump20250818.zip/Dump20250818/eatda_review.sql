-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: eatda
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('FAIL','PENDING','SUCCESS') COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK74d12ba8sxxu9vpnc59b43y30` (`store_id`),
  KEY `FK6cpw2nlklblpvc7hyt7ko6v3e` (`user_id`),
  CONSTRAINT `FK6cpw2nlklblpvc7hyt7ko6v3e` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FK74d12ba8sxxu9vpnc59b43y30` FOREIGN KEY (`store_id`) REFERENCES `store` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'2025-08-15 18:15:28.380765',_binary '\0',NULL,'2025-08-15 18:17:56.743867','베이글이 맛은 있는데 조금 짜서 저한테는 별로였어요ㅠ 다음에는 조금 더 달달한 베이글을 찾아서 먹어보고 싶어요!','SUCCESS',6,13),(4,'2025-08-15 19:06:21.344318',_binary '\0',NULL,'2025-08-15 19:06:34.899201','100120210020200203030020100101010300304020010100101','SUCCESS',9,22),(5,'2025-08-15 19:53:39.893687',_binary '\0',NULL,'2025-08-15 19:53:39.893687',NULL,'PENDING',9,13),(6,'2025-08-15 20:50:44.436013',_binary '\0',NULL,'2025-08-15 20:50:44.436013',NULL,'PENDING',9,13),(7,'2025-08-15 21:18:00.821756',_binary '\0',NULL,'2025-08-15 21:24:00.361258','음식이 진짜 신선하고 재료 본연의 맛이 느껴지는 집이에요. 주변 지인들한테도 추천 많이했는데 다 너무 맛있대요. 다음에 또 갈게요~~','SUCCESS',4,2),(8,'2025-08-15 21:25:28.751805',_binary '\0',NULL,'2025-08-15 21:30:02.129133','음식이 진짜 신선하고 재료 본연의 맛이 느껴지는 집이에요. 주변 지인들한테도 추천 많이했는데 다 너무 맛있대요. 다음에 또 갈게요~~','SUCCESS',4,2),(10,'2025-08-16 02:11:21.757899',_binary '\0',NULL,'2025-08-16 02:14:45.235030','데이트 하기 너무 좋은 분위기에요. 조금 비싸지만 다들 친절하고 맛도 좋아서 다음에 또 갈게요','SUCCESS',17,2),(11,'2025-08-16 02:19:56.596195',_binary '\0',NULL,'2025-08-16 02:21:54.427552','친구가 맛있다고 머리박고 먹어요. 그럴거면 지가 사야지 왜 엔빵하는지 모르겠네','SUCCESS',21,2),(12,'2025-08-16 02:28:10.850645',_binary '\0',NULL,'2025-08-16 02:30:58.383206','고기 신선함, 가격 착함. 알바 고기 잘 구움. 위치 좋음. 에어컨 빵빵함. 추천.','SUCCESS',2,2),(14,'2025-08-16 02:43:26.913609',_binary '\0',NULL,'2025-08-16 02:47:19.450521','고기질이 미쳤어요. 육수 무한리필인점도 좋아요. 많이 시키니 음료수도 서비스로 주셨어요.','SUCCESS',12,2),(15,'2025-08-16 02:51:01.593755',_binary '\0',NULL,'2025-08-16 02:54:13.736759','사장님이 미쳤어요. 사장님이 미쳤어요. 사장님이 미쳤어요. 사장님이 미쳤어요. 사장님이 미쳤어요. 사장님이 미쳤어요. 사장님이 미쳤어요. 사장님이 미쳤어요.','SUCCESS',4,2),(17,'2025-08-16 03:07:15.192365',_binary '\0',NULL,'2025-08-16 03:09:41.583342','바다에서 갇 잡은 고등어를 바로 회로 떴나봐요. 진짜 맛있습니다. 강추!!!!!!','SUCCESS',7,2),(19,'2025-08-16 04:48:30.552486',_binary '\0',NULL,'2025-08-16 04:48:30.552486',NULL,'PENDING',21,26),(28,'2025-08-17 17:14:09.789028',_binary '\0',NULL,'2025-08-17 17:17:42.186267','이 집 화덕 미쳤습니다. 눈 앞에서 바로 피자를 만들고, 화덕에 넣고, 추가로 치즈까지 뿌려주셔요.','SUCCESS',17,26),(31,'2025-08-17 23:38:47.591132',_binary '\0',NULL,'2025-08-17 23:38:47.591132',NULL,'PENDING',2,39),(32,'2025-08-17 23:40:26.365161',_binary '\0',NULL,'2025-08-17 23:40:26.365161',NULL,'PENDING',2,39),(33,'2025-08-17 23:48:22.762115',_binary '\0',NULL,'2025-08-17 23:48:22.762115',NULL,'PENDING',2,39),(34,'2025-08-17 23:49:13.914273',_binary '\0',NULL,'2025-08-17 23:49:13.914273',NULL,'PENDING',2,39),(35,'2025-08-17 23:52:03.762177',_binary '\0',NULL,'2025-08-17 23:52:03.762177',NULL,'PENDING',2,39),(36,'2025-08-17 23:59:07.833850',_binary '\0',NULL,'2025-08-17 23:59:07.833850',NULL,'PENDING',2,39),(37,'2025-08-18 00:01:42.396335',_binary '\0',NULL,'2025-08-18 00:01:42.396335',NULL,'PENDING',2,39),(38,'2025-08-18 00:03:45.738366',_binary '\0',NULL,'2025-08-18 00:03:45.738366',NULL,'PENDING',2,39),(39,'2025-08-18 00:04:47.233597',_binary '\0',NULL,'2025-08-18 00:04:47.233597',NULL,'PENDING',2,39),(40,'2025-08-18 00:05:18.573878',_binary '\0',NULL,'2025-08-18 00:05:18.573878',NULL,'PENDING',2,39),(41,'2025-08-18 00:05:54.736559',_binary '\0',NULL,'2025-08-18 00:05:54.736559',NULL,'PENDING',2,39),(42,'2025-08-18 00:07:19.856678',_binary '\0',NULL,'2025-08-18 00:07:19.856678',NULL,'PENDING',2,39),(43,'2025-08-18 02:52:53.573059',_binary '\0',NULL,'2025-08-18 02:53:59.147790','아니 에스프레소 이거 완전 재밌는 친구네? 왜 이탈리아사람들이 아메리카노를 미워하는지 알거같다','SUCCESS',9,26),(44,'2025-08-18 04:37:49.619624',_binary '\0',NULL,'2025-08-18 04:37:49.619624',NULL,'PENDING',9,26),(45,'2025-08-18 04:49:53.485901',_binary '\0',NULL,'2025-08-18 04:51:40.161848','우리집 뽀삐는 엄청난 피지컬을 지니고있어요. 뽀삐 이름은 제리에요. 더 멋진 이름이였으면 좋았을텐데. 뿡빵이 얼마나 좋아요','SUCCESS',9,26),(46,'2025-08-18 08:00:47.094365',_binary '\0',NULL,'2025-08-18 08:00:47.094365',NULL,'PENDING',2,26),(47,'2025-08-18 08:05:45.146937',_binary '\0',NULL,'2025-08-18 08:06:51.479727','제발 살려주라... 살려줄거아니면 그냥 죽여줘 너무달다','SUCCESS',2,26),(48,'2025-08-18 08:10:05.899362',_binary '\0',NULL,'2025-08-18 08:12:28.566858','아니 저희집 뽀삐가 민트초코 먹고 너무 맛있어서 갑자기 춤을 추기 시작하더라고요 그래서 저도 같이 춤췄어요 ^_____^','SUCCESS',2,26),(49,'2025-08-18 08:47:28.041425',_binary '\0',NULL,'2025-08-18 08:47:28.041425',NULL,'PENDING',2,26),(50,'2025-08-18 08:48:02.131544',_binary '\0',NULL,'2025-08-18 08:48:02.131544',NULL,'PENDING',2,26);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:27:18

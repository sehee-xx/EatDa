-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: eatda
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_asset`
--

DROP TABLE IF EXISTS `event_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_asset` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` bigint NOT NULL,
  `type` enum('IMAGE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prompt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('SUCCESS','PENDING','FAIL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `deleted` bit(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_event_asset_event_id` (`event_id`),
  KEY `idx_event_asset_status` (`status`),
  CONSTRAINT `fk_event_asset_event` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_asset`
--

LOCK TABLES `event_asset` WRITE;
/*!40000 ALTER TABLE `event_asset` DISABLE KEYS */;
INSERT INTO `event_asset` VALUES (1,1,'IMAGE','저희집 뽀삐는 사자에요','SUCCESS','2025-08-15 20:24:27.634052','2025-08-15 20:24:34.272001',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/23/8da4cc88f49e4f9281d0c2bdb5b982c8.png'),(2,2,'IMAGE','미쳤다 떡볶이가 검은색','SUCCESS','2025-08-15 22:24:16.957563','2025-08-15 22:24:21.799947',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/3/8fb35101058343259e1cb280216c0f37.png'),(3,3,'IMAGE','귀여운 강아지보면서 치킨드세요~','SUCCESS','2025-08-16 02:04:33.280647','2025-08-16 02:04:39.238859',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/4839e48487f14e81bd9452fc96eb3637.png'),(4,4,'IMAGE','강아지가 웃고있어요','FAIL','2025-08-16 03:45:03.994648','2025-08-16 03:45:07.774117',_binary '\0',NULL,NULL),(5,5,'IMAGE','강아지가 웃고있어요','SUCCESS','2025-08-16 03:47:38.241674','2025-08-16 03:47:42.869546',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/f7c24ad21d5f438ba5a13f4c3fd39b27.png'),(6,6,'IMAGE','우리집 강아지는 복슬강아지','SUCCESS','2025-08-16 12:56:02.883451','2025-08-16 12:56:11.103036',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/7f83ebc4414b4d2bbed95c506818eac3.png'),(7,7,'IMAGE','강아지가 서빙하는 사진 만들어줘','FAIL','2025-08-17 14:00:34.084016','2025-08-17 14:00:38.387812',_binary '\0',NULL,NULL),(8,8,'IMAGE','강아지가 서빙하는 사진 만들어줘','SUCCESS','2025-08-17 14:12:34.687556','2025-08-17 14:12:39.596425',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/023ea7420d1646b3a2085e34bfc4a5ef.png'),(9,9,'IMAGE','우리집 말티즈가 서빙해주는 사진 만들어줘','SUCCESS','2025-08-17 14:15:49.766072','2025-08-17 14:15:55.902868',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/6bab8f5401744489b2a05af46b8663e1.png'),(10,10,'IMAGE','귀여운 우리집 말티즈에게 먹이를 주세요','SUCCESS','2025-08-17 14:22:00.232414','2025-08-17 14:22:05.578565',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/696d5ea82660457695fe64d90a6818c0.png'),(11,11,'IMAGE','귀여운 우리집 말티즈에게 먹이를 주세요','SUCCESS','2025-08-17 14:25:17.368117','2025-08-17 14:25:22.665784',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/48472edd6f274fe5a0107841486a0cf0.png'),(12,12,'IMAGE','저희집 말티즈 뽀삐가 서빙하는 사진 만들어줘','SUCCESS','2025-08-17 14:30:12.179548','2025-08-17 14:30:18.288913',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/25/b9abd0ded2164144b5ad314c06cb31af.png'),(13,13,'IMAGE','다리가 3개, 날개가 3개인 닭을 그려줘','SUCCESS','2025-08-17 17:24:19.093529','2025-08-17 17:24:24.783499',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/38/aeed49ad402445419cc8f2d35db7ae93.png'),(14,14,'IMAGE','강아지가 누워있는 사진','PENDING','2025-08-17 21:33:54.194021','2025-08-17 21:33:54.194021',_binary '\0',NULL,NULL),(15,15,'IMAGE','강아지가 누워있는 사진을 만들어쥭','PENDING','2025-08-17 21:36:14.334693','2025-08-17 21:36:14.334693',_binary '\0',NULL,NULL),(16,16,'IMAGE','비행기가 날아가는 사진만들어줘','PENDING','2025-08-17 21:39:49.002829','2025-08-17 21:39:49.002829',_binary '\0',NULL,NULL),(17,17,'IMAGE','고양이와 강아지가 서빙하는 모습을 만들어줘','PENDING','2025-08-17 21:48:32.970633','2025-08-17 21:48:32.970633',_binary '\0',NULL,NULL),(18,18,'IMAGE','계란을 하나 더 까서 넣어주는 이미지 만들어줘.','SUCCESS','2025-08-18 00:15:45.123388','2025-08-18 00:15:50.320090',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/27/6fad0fe54afd4dc4884a3fd941ee329d.png'),(19,19,'IMAGE','강아지를 공짜로 만질 수 있어요','FAIL','2025-08-18 06:31:53.777247','2025-08-18 06:31:55.245381',_binary '\0',NULL,NULL),(20,20,'IMAGE','내가 올린 사진에 삶은 계란 2개 추가해줘','FAIL','2025-08-18 07:54:24.708399','2025-08-18 07:54:26.088629',_binary '\0',NULL,NULL),(21,21,'IMAGE','떡볶이에 라면사리를 추가한 이미지를 생성해줘','SUCCESS','2025-08-18 08:16:55.759543','2025-08-18 08:17:01.505961',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/54/06a95948e9674dd59eb9e0b1da98059b.png'),(22,22,'IMAGE','떡볶이에 삶은 계란 2개 올라가있는 사진 생성해줘','SUCCESS','2025-08-18 08:18:43.920532','2025-08-18 08:18:50.464170',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/54/6e33c2b42c874434ab1889255d89b89d.png'),(23,23,'IMAGE','강아지가 서빙하는 사진 생성해줘','SUCCESS','2025-08-18 09:02:56.840262','2025-08-18 09:03:02.895181',_binary '\0',NULL,'https://i13a609.p.ssafy.io/eatda/test/data/images/events/26/9da9e4969bd44e8a8787f4f3f9ebbc99.png');
/*!40000 ALTER TABLE `event_asset` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:28:05

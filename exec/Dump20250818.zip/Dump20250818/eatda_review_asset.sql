-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: eatda
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review_asset`
--

DROP TABLE IF EXISTS `review_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_asset` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `asset_url` text COLLATE utf8mb4_unicode_ci,
  `prompt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('FAIL','PENDING','SUCCESS') COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('IMAGE','SHORTS_GEN_4','SHORTS_RAY_2') COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_id` bigint NOT NULL,
  `image_url` text COLLATE utf8mb4_unicode_ci,
  `shorts_url` text COLLATE utf8mb4_unicode_ci,
  `thumbnail_path` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKsrir9deu2wkkfo7sffkddfp0p` (`review_id`),
  CONSTRAINT `FK2o76b0qfyvoho46p2n1dvjwxy` FOREIGN KEY (`review_id`) REFERENCES `review` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_asset`
--

LOCK TABLES `review_asset` WRITE;
/*!40000 ALTER TABLE `review_asset` DISABLE KEYS */;
INSERT INTO `review_asset` VALUES (1,NULL,'베이글을 맛있게 먹으면서 짜서 짜증난다는 표정을 짓는 20대 여자의 모습을 그려줘','SUCCESS','SHORTS_GEN_4',1,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/5bad7acfeb7e4b98a9d8ea3a733825b4.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/maoka294@naver.com/thumbnail/755edb0a-9d20-4fc1-909b-55b3fd074e63.jpg'),(4,NULL,'101001020r939020030300304020010110','SUCCESS','IMAGE',4,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/22/8da5c6355c59446fbf06fc8d304516f8.png',NULL,NULL),(5,NULL,'리뷰개수 2개로 늘어나게해주세요','FAIL','IMAGE',5,NULL,NULL,NULL),(6,NULL,'저희집 뽀뽀는 토끼에요','FAIL','IMAGE',6,NULL,NULL,NULL),(7,NULL,'유튜버 햄찌 캐릭터가 나와서 한입 베어먹고 도망가는 영상 만들어줘.','SUCCESS','SHORTS_RAY_2',7,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/b774c5d424d4428a8747ca5fa6b002b2.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/7f792ece-4542-4751-806d-27a01575ce86_resultc3937d576f6b1d00.jpg'),(8,NULL,'햄스터가 나와서 한입 베어먹고 도망가는 영상 만들어줘.','SUCCESS','SHORTS_RAY_2',8,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/5e0253da562b43f2a5c6f0cd49c34566.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/c80f68c1-b10a-45d5-85f4-d202a9711924_result34d54c9ed152b266.jpg'),(10,NULL,'음식먹던 사람이 갑자기 품속에서 권총을 꺼내서 총을 쏴','SUCCESS','SHORTS_RAY_2',10,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/31a992f2920b47da98cab86794b86c77.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/1e1a66e6-a5f7-4f4a-b44e-9478c3059e5c_resultc8d67666c8062db8.jpg'),(11,NULL,'음식에 얼굴박고 먹는 한국인 남자 그려줘.','SUCCESS','SHORTS_GEN_4',11,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/51e0093bdae6471494892b845a1d2093.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/633bed56-a5d0-4e31-97e6-2a44326fe300.jpg'),(12,NULL,'햄스터도 옆에서 소주랑 구워진 고기를 먹고 있어.','SUCCESS','SHORTS_RAY_2',12,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/2efded5c4c614c72931138c88b10ceba.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/0c9ef258-6c16-4e06-a1f1-8bed61a8f1b4_resultcf1b8c0b48a94362.jpg'),(14,NULL,'맛있어보이게 좀  꾸며봐','SUCCESS','SHORTS_RAY_2',14,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/c6a869b4d2714c45b63830151574bec0.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/d4005e64-8ece-4a77-a3e5-3eb149ccccd4_result55728dba6430ad2c.jpg'),(15,NULL,'지브리풍으로 재밌게 바꿔줘.','SUCCESS','SHORTS_RAY_2',15,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/019f24d9c0024582be900da8737fa141.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/bc53dc95-8bfb-4791-bb2c-c5f7187c2567_result02a79b08aa997efd.jpg'),(17,NULL,'바다에서 갇 잡은 고등어가 바로 회가 되었어.','SUCCESS','SHORTS_RAY_2',17,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/5d3b43b01f90488cbd4602e2d3661314.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/sei2@sei2.com/thumbnail/d8a9d822-d256-454c-ab81-e8c3ad9f5435_result090dc4df78da6e4d.jpg'),(19,NULL,'저희 집 뽀삐가 너무 맛있어서 뼈째로 먹었어요','FAIL','IMAGE',19,NULL,NULL,NULL),(28,NULL,'화덕에서 갇 나온 피자에 치즈를 뿌려줘.','SUCCESS','SHORTS_RAY_2',28,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/10dade3ce6ca47a6b7a9eb6083b0b06b.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/1@t.com/thumbnail/f4316ea7-206b-48f2-bc1c-04e0ecc945d0_resultb794183a268db51c.jpg'),(31,NULL,'텐동을 맛있게 먹는 20대를 그려줘','PENDING','SHORTS_RAY_2',31,NULL,NULL,NULL),(32,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','SHORTS_GEN_4',32,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/75df4a72b81643179a8a73f8384de26e.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/tkddls0127@naver.com/thumbnail/fb660c0a-3536-432c-9b34-d158fd835b20.jpg'),(33,NULL,'텐동을 맛있게 먹는 20대를 그려줘','FAIL','IMAGE',33,NULL,NULL,NULL),(34,NULL,'텐동을 맛있게 먹는 20대를 그려줘','PENDING','SHORTS_RAY_2',34,NULL,NULL,NULL),(35,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','SHORTS_RAY_2',35,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/71e44c473b45411fb24c5f7f8750ae5b.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/tkddls0127@naver.com/thumbnail/dab7de9b-147a-4f28-9da0-2f288b5ec178_result1d814052998152ab.jpg'),(36,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','IMAGE',36,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/39/310ee061300e4f5cbdeed75d2aa9f3cf.png',NULL,NULL),(37,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','SHORTS_RAY_2',37,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/0ac449c7e2f04dde80e7bc2477e8d778.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/tkddls0127@naver.com/thumbnail/109eb4ae-6c12-47b5-8c42-19ff715a6b3b_result8b38359eba24d5b1.jpg'),(38,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','SHORTS_GEN_4',38,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/6fa2b37a3ea9446e8408d7ebce96e44e.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/tkddls0127@naver.com/thumbnail/a5c4eef5-903a-4d52-b556-2fef3da22689.jpg'),(39,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','IMAGE',39,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/39/e2215fd6d9ff416495a49f49d693faa7.png',NULL,NULL),(40,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','IMAGE',40,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/39/899ed3c20c7b4a23a7d9bb13d4a5246c.png',NULL,NULL),(41,NULL,'텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','IMAGE',41,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/39/3b312284c1c1498ead64d3ef6a39c130.png',NULL,NULL),(42,NULL,'이 음식을 맛있게 먹는 20대 남자를 그려줘','SUCCESS','IMAGE',42,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/39/58b8531328a949dc9170fe5664bbe636.png',NULL,NULL),(43,NULL,'에스프레소를 먹고 힘내서 재활하는 남자 표현해줘','SUCCESS','SHORTS_GEN_4',43,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/7753754c0bcd4a8eaf6160d384e43180.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/1@t.com/thumbnail/5138297e-9456-42bc-8fe5-3d1c8df69b73.jpg'),(44,NULL,'에스프레소가 너무 맛있어서 저희집 삐뽀가 주인몰래 먹어요','FAIL','SHORTS_GEN_4',44,NULL,NULL,NULL),(45,NULL,'에스프레소를 먹고 에너지넘쳐서 운동 열심히 해서 어깨깡패가 된 말티즈','SUCCESS','SHORTS_GEN_4',45,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/15a4044159a5425a942addae17fb018f.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/1@t.com/thumbnail/1c5d410d-4de4-4086-af2b-3be3266abcf7.jpg'),(46,NULL,'너무 달아서 계속 먹고 돼지가된 남자 그려줘','FAIL','IMAGE',46,NULL,NULL,NULL),(47,NULL,'너무 달아서 샷추가가 필요한 초코렛음료수 그려줘','SUCCESS','SHORTS_GEN_4',47,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/02a192d1059b45778986cfbe00a76c57.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/1@t.com/thumbnail/f40880b3-2f39-4fab-9166-0e58c4678eca.jpg'),(48,NULL,'민트초코 마시고 충격받아서 춤추는 강아지 영상 생성해줘','SUCCESS','SHORTS_RAY_2',48,NULL,'https://i13a609.p.ssafy.io/eatda/test/data/videos/data/8339f7be63554157a519f8c90c3c1c66.mp4','https://i13a609.p.ssafy.io/eatda/test/data/shorts/1@t.com/thumbnail/27afa5e1-5b8f-4ab8-b770-be6dfae4cf02_resultdfc4b069344a859a.jpg'),(49,NULL,'10','SUCCESS','IMAGE',49,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/26/1ba4a15812fa4bff942ff5d7e92a3657.png',NULL,NULL),(50,NULL,'김밥떡볶이','SUCCESS','IMAGE',50,'https://i13a609.p.ssafy.io/eatda/test/data/images/reviews/26/0310714b26834dc0b564a1ad98d477fe.png',NULL,NULL);
/*!40000 ALTER TABLE `review_asset` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:27:32

-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: eatda
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu_poster_asset`
--

DROP TABLE IF EXISTS `menu_poster_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_poster_asset` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `prompt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('FAIL','PENDING','SUCCESS') COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('IMAGE','SHORTS_GEN_4','SHORTS_RAY_2') COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_poster_id` bigint NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKf789jgpeoeb79p7fqaktumbuv` (`menu_poster_id`),
  CONSTRAINT `FK2njb0svsd16wrviixaqm6uci1` FOREIGN KEY (`menu_poster_id`) REFERENCES `menu_poster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_poster_asset`
--

LOCK TABLES `menu_poster_asset` WRITE;
/*!40000 ALTER TABLE `menu_poster_asset` DISABLE KEYS */;
INSERT INTO `menu_poster_asset` VALUES (1,'2025-08-15 17:28:17.077552',_binary '\0',NULL,'2025-08-15 17:28:26.024666','101010010101010010101001010010101010010010101010100 1728','SUCCESS','IMAGE',1,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/817b650176914e50bb11621b8f9d6ea5.png'),(2,'2025-08-15 17:32:30.088714',_binary '\0',NULL,'2025-08-15 17:32:39.513993','101010010101010010101001010010101010010010101010100 1728','SUCCESS','IMAGE',2,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/d45f665d775e42f28dc5e1f44ea5df4b.png'),(3,'2025-08-15 17:37:00.576080',_binary '\0',NULL,'2025-08-15 17:37:09.177373','101010010101010010101001010010101010010010101010100 1728','SUCCESS','IMAGE',3,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/f3caeefec90f4ba992e647c86f193158.png'),(4,'2025-08-15 17:45:21.316660',_binary '\0',NULL,'2025-08-15 17:45:28.520993','Diiwisixiejjxhcjsjxjjeiwiz','SUCCESS','IMAGE',4,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/4e2074c0ff4b43979443ff39854868d8.png'),(5,'2025-08-15 20:39:41.356104',_binary '\0',NULL,'2025-08-15 20:39:49.880790','뽀삐는 사자에요','SUCCESS','IMAGE',5,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/d20688c6c2144d7c8c4e0ca1853cf330.png'),(6,'2025-08-15 21:07:45.396514',_binary '\0',NULL,'2025-08-15 21:07:53.335258','뽀삐는 삐뽀에용','SUCCESS','IMAGE',6,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/367f8bafeb8d466d852011c003a5e8bf.png'),(7,'2025-08-15 21:10:57.770823',_binary '\0',NULL,'2025-08-15 21:11:06.621118','뽀삐는 삐뽀에용','SUCCESS','IMAGE',7,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/a0cd305d8cbd4b2696e24f5d808d450e.png'),(8,'2025-08-15 21:19:17.139697',_binary '\0',NULL,'2025-08-15 21:19:25.379123','뽀삐는 삐뽀에용','SUCCESS','IMAGE',8,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/d7554a835197463e82de4b8173ab1507.png'),(9,'2025-08-15 21:20:41.965730',_binary '\0',NULL,'2025-08-15 21:20:49.984314','뽀삐는 삐뽀','SUCCESS','IMAGE',9,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/c2cef0a1d8c64098b2b42a322730ad87.png'),(10,'2025-08-15 21:30:18.202970',_binary '\0',NULL,'2025-08-15 21:30:28.718680','뽀삐는삐뽀','SUCCESS','IMAGE',10,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/8245267cde7c45209b6789858945d4fd.png'),(11,'2025-08-15 21:35:37.101433',_binary '\0',NULL,'2025-08-15 21:35:45.942571','떡볶이가 검정색','SUCCESS','IMAGE',11,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/34ebac804dbb411fb084fd8ca2387a1a.png'),(12,'2025-08-15 21:44:44.688189',_binary '\0',NULL,'2025-08-15 21:44:53.921996','뽀삐는삐뽀','SUCCESS','IMAGE',12,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/c19eafcd18034e1984ee1920364f2c4d.png'),(13,'2025-08-15 23:42:30.271321',_binary '\0',NULL,'2025-08-15 23:42:39.299011','아메리카노에서 사자기운이 솟구쳐용','SUCCESS','IMAGE',13,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/13/f0e1043611214b0d888f5788dec34710.png'),(14,'2025-08-16 01:01:34.884210',_binary '\0',NULL,'2025-08-16 01:01:45.068493','치킨집인데 떡볶이 개맛도리 미슐랭3스타 넣어주세요','SUCCESS','IMAGE',14,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/f2754dc1fa0b4225838088f213f0ef1b.png'),(15,'2025-08-16 13:00:40.282558',_binary '\0',NULL,'2025-08-16 13:00:48.572884','뽀삐가 좋아하는 치킨','SUCCESS','IMAGE',15,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/dbef0a9b255a47fda04743763c2a1e13.png'),(16,'2025-08-17 03:56:29.410327',_binary '\0',NULL,'2025-08-17 03:56:36.663729','건전지 사기 귀찮아서 2달째 일을 안하고있는 시계. 저거에 건전지를 넣었더라면 지각을 덜했을까? 라는 생각을 하고있는 우리집 뽀삐를 메뉴판에 넣어줘','SUCCESS','IMAGE',16,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/512112e87a514718937f25b858cd2c2c.png'),(17,'2025-08-17 04:04:42.664998',_binary '\0',NULL,'2025-08-17 04:04:51.296609','건전지 사기 귀찮아서 2달째 일을 안하고있는 시계. 저거에 건전지를 넣었더라면 지각을 덜했을까? 라는 생각을 하고있는 우리집 뽀삐를 메뉴판에 넣어줘','SUCCESS','IMAGE',17,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/e5486b0525b34daaa632d0b14acb5615.png'),(18,'2025-08-17 12:40:21.392758',_binary '\0',NULL,'2025-08-17 12:40:30.055204','저 강아지는 사실 골든리트리버입니다','SUCCESS','IMAGE',18,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/18c9cceda61542f4acef425e73c99db4.png'),(19,'2025-08-17 12:50:42.284560',_binary '\0',NULL,'2025-08-17 12:50:49.790768','뽀삐는 호랑이에요','SUCCESS','IMAGE',19,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/3a91c03a395841ec925bc1cf476584c9.png'),(20,'2025-08-17 12:53:44.204338',_binary '\0',NULL,'2025-08-17 12:53:53.057287','미슐랭3스타급 치킨','SUCCESS','IMAGE',20,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/8d41e1125dd34da3a5de69695e1ecc61.png'),(21,'2025-08-17 13:04:20.987949',_binary '\0',NULL,'2025-08-17 13:04:28.856165','우리집 뽀삐도 안먹는 음식','SUCCESS','IMAGE',21,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/db662f96b64241c8a35b5ec0f212b289.png'),(22,'2025-08-17 13:12:03.337189',_binary '\0',NULL,'2025-08-17 13:12:11.734126','치킨다리가 3개','SUCCESS','IMAGE',22,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/bbc8bac996784b30bf0e9d21803f2e56.png'),(23,'2025-08-17 17:28:28.060151',_binary '\0',NULL,'2025-08-17 17:28:35.969961','다리가 3개인 닭이 있고 다리가 2개인 병아리를 그려줘','SUCCESS','IMAGE',23,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/37/53c603797ce241c7b1d8183232d869d7.png'),(24,'2025-08-17 22:10:01.684338',_binary '\0',NULL,'2025-08-17 22:10:01.684338','닭다리가 사람 얼굴만하다는걸 표현하는 사진 만들어줘','PENDING','IMAGE',24,NULL),(25,'2025-08-18 00:00:37.407786',_binary '\0',NULL,'2025-08-18 00:00:46.401787','텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','IMAGE',25,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/39/44ce46c3017e466a93434d9a7f5de3bd.png'),(26,'2025-08-18 00:06:41.171539',_binary '\0',NULL,'2025-08-18 00:06:48.923074','텐동을 맛있게 먹는 20대를 그려줘','SUCCESS','IMAGE',26,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/39/1c5a794e395a4f978c2db73a7635fa36.png'),(27,'2025-08-18 04:35:46.330605',_binary '\0',NULL,'2025-08-18 04:35:54.721699','몰래 먹다가 들킨 뽀뽀','SUCCESS','IMAGE',27,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/3116c924d79e4b5d970b067c3dc969fb.png'),(28,'2025-08-18 08:14:43.218653',_binary '\0',NULL,'2025-08-18 08:14:52.414087','고양이가 자바칩 푸라푸치노 만드는 사진 생성해줘','SUCCESS','IMAGE',28,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/d542af89cee34bc792ba70ba2a28cf47.png'),(29,'2025-08-18 08:38:15.724628',_binary '\0',NULL,'2025-08-18 08:38:24.774128','떡만두국에 돈까스가 들어가져있는 사진 생성해줘','SUCCESS','IMAGE',29,'https://i13a609.p.ssafy.io/eatda/test/data/images/menuPosters/26/a4dbc030f1b2482a95c336e404988dd5.png');
/*!40000 ALTER TABLE `menu_poster_asset` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:28:14
